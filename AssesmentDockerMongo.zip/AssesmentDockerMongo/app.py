from flask import Flask, request
from flask_restful import Resource, Api, reqparse
from pymongo import MongoClient
from bson import ObjectId
from flask_cors import CORS


app = Flask(__name__)
CORS(app)
api = Api(app)


client = MongoClient('mongodb://db:27017/')

db = client.customer_db
customers = db.customer

parser = reqparse.RequestParser()
parser.add_argument('customerId', type=int, required=True, help='ID cannot be blank')
parser.add_argument('customerName', type=str, required=True, help='Name cannot be blank')
parser.add_argument('customerMobile', type=str, required=True, help='Mobile cannot be blank')
parser.add_argument('customerAddress', type=str, required=True, help='Address cannot be blank')


class Customer(Resource):
    def get(self,customer_id=None):
        if customer_id:
            customer = customers.find_one({'_id': ObjectId(customer_id)})
            if customer:
                customer['_id'] = str(customer['_id'])
                return customer, 200
            return {'message': 'Customer not found'}, 404
        else:
            all_customers = list(customers.find())
            for customer in all_customers:
                customer['_id'] = str(customer['_id'])
        return all_customers,200

    def post(self):
        args = parser.parse_args()
        customer_id = args["customerId"]
        customer_exists = customers.find_one({"customerId": customer_id})
        if customer_exists is not None:
            return {"message": "Customer Id  already exists"},409
        result=customers.insert_one({"customerId":args["customerId"],"customerName":args["customerName"],
                                     "customerMobile":args["customerMobile"],"customerAddress":args["customerAddress"]})
        return {"id":str(result.inserted_id),"customerId":args["customerId"],"customerName":args["customerName"],
                "customerMobile":args["customerMobile"]
                   ,"customerAddress":args["customerAddress"]},201


    def delete(self,customer_id):
        customers.delete_one({"_id":ObjectId(customer_id)})
        return {"message":"Book deleted successfully"},200


api.add_resource(Customer, '/customers', '/customers/<string:customer_id>')
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)


